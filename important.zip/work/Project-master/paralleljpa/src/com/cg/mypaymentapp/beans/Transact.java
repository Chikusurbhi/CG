package com.cg.mypaymentapp.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="transactionss")
public class Transact {

	@Id
	@Column(name="i")
	Integer i;
	@Column(name="tr")
	String tr;

	
	
	
	public Transact() {
		// TODO Auto-generated constructor stub
	}




	public Integer getI() {
		return i;
	}




	public void setI(Integer i) {
		this.i = i;
	}




	public String getTr() {
		return tr;
	}




	public void setTr(String tr) {
		this.tr = tr;
	}




	public Transact(Integer i, String tr) {
		super();
		this.i = i;
		this.tr = tr;
	}




	@Override
	public String toString() {
		return "Transact [i=" + i + ", tr=" + tr + "]";
	}
	
	
}
