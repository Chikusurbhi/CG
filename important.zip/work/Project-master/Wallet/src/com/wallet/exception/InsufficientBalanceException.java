package com.wallet.exception;

public class InsufficientBalanceException extends Exception {

	public InsufficientBalanceException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}
}
