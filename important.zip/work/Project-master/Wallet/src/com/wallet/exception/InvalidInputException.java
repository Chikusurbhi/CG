package com.wallet.exception;

public class InvalidInputException extends Exception {

	public InvalidInputException(String s) {
		super(s);
		// TODO Auto-generated constructor stub
	}

}
