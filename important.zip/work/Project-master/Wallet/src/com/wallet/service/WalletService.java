package com.wallet.service;
import com.wallet.exception.*;
import com.wallet.beans.Customer;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;



	public interface WalletService {
		// TODO Auto-generated constructor stub
		public Customer createAccount(String custMobNo, String custName, BigDecimal balance) throws InvalidInputException;
		public Customer showBalance (String mobileno) throws InvalidInputException;
		public Customer fundTransfer (String sourceMobileNo,String targetMobileNo, BigDecimal balance) throws InvalidInputException;
		public Customer depositAmount (String mobileNo,BigDecimal balance ) throws InvalidInputException;
		public Customer withdrawAmount(String mobileNo,BigDecimal balance) throws InsufficientBalanceException, InvalidInputException;
	

		public boolean ValidateName(String name) throws InvalidInputException;
		public boolean ValidateMobNo(String MobNo) throws InvalidInputException;
		public boolean ValidateAmount(BigDecimal balance) throws InvalidInputException;



		
	}

