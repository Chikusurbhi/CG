package com.wallet.repo;

import com.wallet.beans.Customer;


public interface WalletRepo
{

	public boolean save(Customer customer);

	public Customer findOne(String MobileNo);


}
