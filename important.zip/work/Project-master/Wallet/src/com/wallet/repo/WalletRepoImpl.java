package com.wallet.repo;

import java.util.Map;

import com.wallet.beans.Customer;
import com.wallet.beans.Wallet;
import java.math.BigDecimal;

public class WalletRepoImpl implements WalletRepo {
	Map<String,Customer> cMap;
	public WalletRepoImpl() {
		cMap=DBStore.createCollection();
		cMap.put("7408316888",new Customer("Syed","7408316888",new Wallet(BigDecimal.valueOf(5000))));
	}
	@Override
	public boolean save(Customer customer) {
		if(customer!=null) {
			cMap.put(customer.getMobNo(),customer);
			return true;
		}
		return false;
		
	}
	@Override
	
	
	
	
	
	
	
	
	public Customer findOne(String MobileNo) {
		if(cMap.containsKey(MobileNo)) {
			Customer customer=cMap.get(MobileNo);
			return customer;
	}
		return null;
	}
}
	