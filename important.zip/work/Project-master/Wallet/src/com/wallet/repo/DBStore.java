package com.wallet.repo;
import java.util.HashMap;
import java.util.Map;

import com.wallet.beans.Customer;
public class DBStore {
	private static Map<String,Customer> customer;
	public static Map<String,Customer>createCollection(){
		if(customer==null)
			customer=new HashMap<>();
		return customer;
	

	
		
		// TODO Auto-generated constructor stub
	}

}
