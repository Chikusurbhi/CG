package com.wallet.beans;

public class Customer {
	private String name;
	private String MobNo;
	private  Wallet wallet;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getMobNo() {
		return MobNo;
	}

	public void setMobNo(String mobNo) {
		this.MobNo = mobNo;
	}

	public  Wallet getWallet() {
		return wallet;
	}

	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	@Override
	public String toString() {
		return "Customer[MobileNo="+MobNo +",Name="+name +",Wallet="+wallet+"]";
	}

	public Customer(String name, String mobNo,Wallet wallet) {
		super();
		this.name = name;
		this.MobNo = mobNo;
		this.wallet = wallet;
	}
	
	
	}





