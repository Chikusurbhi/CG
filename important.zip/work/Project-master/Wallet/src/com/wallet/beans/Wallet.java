package com.wallet.beans;

import java.math.BigDecimal;

public class Wallet {
	private BigDecimal Balance;

	public Wallet(BigDecimal balance) {
		super();
		this.Balance=balance;
		
		// TODO Auto-generated constructor stub
	}

	public BigDecimal getBalance() {
		return Balance;
	}

	public void setBalance(BigDecimal balance) {
		this.Balance = balance;
	}

	@Override
	public String toString() {
		return "Wallet [Balance=" + Balance + "]";
	}
		
	}
	

