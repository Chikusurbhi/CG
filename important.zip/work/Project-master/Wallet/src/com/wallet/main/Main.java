package com.wallet.main;

import java.math.BigDecimal;
import java.util.Scanner;

import com.wallet.beans.Customer;
import com.wallet.beans.Wallet;
import com.wallet.exception.InsufficientBalanceException;
import com.wallet.exception.InvalidInputException;
import com.wallet.service.WalletService;
import com.wallet.service.WalletServiceImpl;

public class Main {
	static Scanner sc = new Scanner(System.in);;

	public static void main(String[] args) {
		WalletService service=new WalletServiceImpl();
			
		int choice=0;
			
		while(true){
			System.out.println("--------Payment Wallet----");
			System.out.println("1:Create Account");
			System.out.println("2:Display Balance");
			System.out.println("3.Deposit");
			System.out.println("4.Withdraw");
			System.out.println("5.Fund Transfer");
			System.out.println("6.Transations");	
			System.out.println("7.Exit");
			System.out.println("\nEnter Your Choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: 
					/*System.out.println("Please Enter Your Name");
					String customerName=sc.next();
					System.out.println("Please Enter Money you wanted to add");
					BigDecimal balance=sc.nextBigDecimal();
					*/
							
						System.out.println("Please Enter Your Mobile Number");
					String customerMobileNUmber=sc.next();
					try {
						
						if(service.ValidateMobNo(customerMobileNUmber)){
							
							}
						else
							throw new InvalidInputException("Enter Ten Digit Number starting with 6/7/8/9  ");
					} catch (InvalidInputException e) {
						System.out.println("Invalid Mobile Number");
					}
					break;
				
				
			case 2: System.out.println("Please Enter Your Mobile Number");
					String custMobNo1=sc.next();
					try {
						if(service.ValidateMobNo(custMobNo1)){
							Customer customer=service.showBalance(custMobNo1);
							
								Wallet wallet=customer.getWallet();
								System.out.println("Hi "+customer.getName()+", your balance is "+wallet.getBalance() +" !!");
										
							}
						else
							throw new InvalidInputException("Enter Ten Digit Number starting with 6/7/8/9  ");
					} catch (InvalidInputException e) {
						System.out.println("Invalid Mobile Number");
					}
					
					
					break;
					
				
			case 3: System.out.println("Please Enter Your Mobile Number");
					custMobNo1=sc.next();
					try {
						if(service.ValidateMobNo(custMobNo1)){
						 Customer customer=service.showBalance(custMobNo1);
						 Wallet wallet =customer.getWallet();
						 System.out.println("Hi "+customer.getName()+", your current balance is "+wallet.getBalance() +" !!");
						 System.out.println("Please Enter the amount you want to deposit ");
						 BigDecimal deposit=sc.nextBigDecimal();
						 customer=service.depositAmount(custMobNo1, deposit);
						 wallet =customer.getWallet();
						 System.out.println("Hi "+customer.getName()+", your updated balance is "+wallet.getBalance() +" !!");
						}
						else
							throw new InvalidInputException("Enter  Ten Digit Mobile Number  ");
					} catch (InvalidInputException e) {		
						
					}
						
					 break;
					 
			case 4: System.out.println("Please Enter Your Mobile Number");
					custMobNo1=sc.next();
					try {
						if(service.ValidateMobNo(custMobNo1)){
						 Customer customer=service.showBalance(custMobNo1);
						 Wallet wallet=customer.getWallet();
						 System.out.println("Hi "+customer.getName()+", your current balance is "+wallet.getBalance() +"  !!");
						 System.out.println("Please Enter the amount you want to withdraw ");
						 BigDecimal withdraw=sc.nextBigDecimal();
						 try {
							customer=service.withdrawAmount(custMobNo1, withdraw);
						} catch (InsufficientBalanceException e) {
							
						}
						 wallet=customer.getWallet();
						 System.out.println("Hi "+customer.getName()+", your updated balance is "+wallet.getBalance() +"  !!");
						}
						else 
							throw new InvalidInputException("Enter Ten Digit Mobile Number  ");
					} catch (InvalidInputException e) {
					
					}
					 break;
					 
					 
			case 5: System.out.println("Please Enter Your Mobile Number");
					String custMobNoS=sc.next();
					try {
						if(service.ValidateMobNo(custMobNoS)){
							Customer customer=service.showBalance(custMobNoS);
							Wallet w=customer.getWallet();
							System.out.println("Hi "+customer.getName()+", your current balance is "+w.getBalance() +"  !!");
							System.out.println("Please Enter the mobile number  you want to transfer money ");
							String custMobNoT=sc.next();
							if(service.ValidateMobNo(custMobNoT)){
							System.out.println("Please Enter amount to be transferred ");
							
							BigDecimal ft=sc.nextBigDecimal();
						 
							customer=service.fundTransfer(custMobNoS, custMobNoT, ft);
							w=customer.getWallet();
							System.out.println("Hi "+customer.getName()+", your updated balance is "+w.getBalance() +"  !!");
						} }
						else
							try {
								throw new InvalidInputException("Enter Ten Digit Mobile Number  ");
							} catch (InvalidInputException e) {
							
							}
					} catch (InvalidInputException e) {
						
					}
					
					 break;
					 
			case 6: WalletServiceImpl s=new WalletServiceImpl();
					String[] trans=s.getDeposit();
					for(String tran:trans)
					System.out.println(tran);
					break;
				
		    case 7: System.out.println("Successfully Teminated");
				    System.exit(0);
				    break;
				    
			default: System.out.println("Wrong Input");
				
			}
		}
			
		}

}
