package com.banking.repo;
import com.banking.model.Account;

	public interface AccountRepository {
		
		boolean save(Account account);
		
		Account searchAccount(int accountNumber);

	}
