package com.banking.service;

import com.banking.exceptions.InsufficientInitialAmountException;
import com.banking.model.Account;
import com.banking.repo.AccountRepository;

public class AccountServiceImpl implements AccountService {
	AccountRepository accountRepository;

	public AccountServiceImpl(AccountRepository accountRepository) {
		super();
		this.accountRepository = accountRepository;
	}

	@Override
	public Account createAccount(int accountNumber, int amount) throws InsufficientInitialAmountException {
		int p, q, r;
		if (amount < 1000) {
			throw new InsufficientInitialAmountException();
		}
		Account account = new Account();
		account.setAccountNo(accountNumber);
		account.setAmount(amount);
		if (accountRepository.save(account)) {
			return account;
		}
		return null;

	}

}
