package com.banking.service;

import com.banking.exceptions.InsufficientInitialAmountException;
import com.banking.model.Account;

public interface AccountService {

	Account createAccount(int accountNumber, int amount) throws InsufficientInitialAmountException;

}