package com.banking.exceptions;

public class InsufficientInitialAmountException extends Exception {

}
