package com.banking.exceptions;

public class InsufficientBalanceException extends Exception {
}
