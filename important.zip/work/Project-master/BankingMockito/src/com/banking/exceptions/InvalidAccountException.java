package com.banking.exceptions;

public class InvalidAccountException extends Exception {

}
