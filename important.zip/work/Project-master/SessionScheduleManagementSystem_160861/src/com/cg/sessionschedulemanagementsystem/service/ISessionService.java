package com.cg.sessionschedulemanagementsystem.service;

import java.util.List;

import com.cg.sessionschedulemanagementsystem.beans.SessionSchedule;

public interface ISessionService {
	
	public List<SessionSchedule> getSessionSchedule();

	
	
}
