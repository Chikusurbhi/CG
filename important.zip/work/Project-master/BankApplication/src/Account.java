
public class Account {
	private int AccountNo;
	private int amount;

	public Account(int accountNo, int amount) {
		super();
		AccountNo = accountNo;
		this.amount = amount;
	}

	public int getAccountNo() {
		return AccountNo;
	}

	public void setAccountNo(int accountNo) {
		AccountNo = accountNo;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}
}
