
public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ICICIBank bank = new ICICIBank();
		System.out.println(bank.CreateAccount(007, 3000));
		try {
			System.out.println("Balance=" + bank.WithdrawAmount(007, 2000));
		} catch (InvalidAccountNumberException ae) {
			System.out.println("invalid account number");

		} catch (InsufficientBalanceException i) {
			System.out.println("insufficient balance");
		}
	}

}
