import java.util.*;

public class ICICIBank {
	LinkedList<Account> accounts = new LinkedList<>();

	public String CreateAccount(int accountNumber, int amount) {
		Account account = new Account(accountNumber, amount);
		accounts.add(account);
		return "new account created succesfully";
	}

	private Account SearchAccount(int accountNumber) throws InvalidAccountNumberException {
		for (Account account : accounts) {
			if (account.getAccountNo() == accountNumber) {
				return account;
			}
		}
		throw new InvalidAccountNumberException();
	}

	public int WithdrawAmount(int accountNumber, int amount)
			throws InvalidAccountNumberException, InsufficientBalanceException {
		Account account = SearchAccount(accountNumber);
		if ((account.getAmount() - amount) >= 0) {
			account.setAmount(account.getAmount() - amount);
			return account.getAmount();
		}
		throw new InsufficientBalanceException();

	}

}
