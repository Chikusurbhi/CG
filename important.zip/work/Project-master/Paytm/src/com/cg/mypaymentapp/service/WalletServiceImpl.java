package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.mypaymentapp.beans.Customer;
import com.cg.mypaymentapp.beans.Wallet;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.repo.WalletRepo;
import com.cg.mypaymentapp.repo.WalletRepoImpl;

public class WalletServiceImpl implements WalletService {

	WalletRepo wrepo;
	String[] dep;
	public String[] getDep() {
		return dep;
	}


	public void setDep(String[] dep) {
		this.dep = dep;
	}

	//= new String[100];
	int i=0;
	
	public WalletServiceImpl() {
		wrepo=new WalletRepoImpl();
	}
	
	
	@Override
	public Customer createAccount(String name, String mobileno,
			BigDecimal amount) throws InvalidInputException{
		Wallet w=new Wallet(amount);
		Customer c=new Customer(name, mobileno, w);
		if(wrepo.save(c)){
			return c;
		}
		
		return null;
		
	}

	@Override
	public Customer showBalance(String mobileno) throws InvalidInputException {
		
		Customer cust=wrepo.findOne(mobileno);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		else
		return cust;
	}

	@Override
	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo,
			BigDecimal amount) throws InvalidInputException {
		
		Customer cust1=wrepo.findOne(sourceMobileNo);
		if(cust1==null)
			throw new InvalidInputException("Number not registered");
		Wallet w1=cust1.getWallet();
		BigDecimal currentbal=w1.getBalance();
		Customer cust2=wrepo.findOne(targetMobileNo);
		if(cust2==null)
			throw new InvalidInputException("Number not registered");
		Wallet w2=cust2.getWallet();
		BigDecimal currentbal2=w2.getBalance();
		
		if(currentbal.compareTo(amount)<0)
			throw new InvalidInputException("Your account balance is less than amount you are transferring");
		
		currentbal2= currentbal2.add(amount);
		currentbal= currentbal.subtract(amount);
		w1.setBalance(currentbal);
		cust1.setWallet(w1);
		wrepo.save(cust1);
		
		w2.setBalance(currentbal2);
		cust2.setWallet(w2);
		wrepo.save(cust2);
		
		
		Customer cust3=wrepo.findOne(sourceMobileNo);
		
		return cust3;
	}

	@Override
	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException {
		
		Customer cust=wrepo.findOne(mobileNo);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		Wallet w=cust.getWallet();
		BigDecimal currentbal=w.getBalance();
		
		BigDecimal newbal= currentbal.add(amount);
		w.setBalance(newbal);
		cust.setWallet(w);
		wrepo.save(cust);
		
		Customer cust1=wrepo.findOne(mobileNo);
		
		//dep[0]= "Deposited amount "+amount;
		//i++;
		return cust1;
	}

	@Override
	public Customer withdrawAmount(String mobileNo, BigDecimal amount) throws InsufficientBalanceException, InvalidInputException {
		Customer cust=wrepo.findOne(mobileNo);
		if(cust==null)
			throw new InvalidInputException("Number not registered");
		Wallet w=cust.getWallet();
		BigDecimal currentbal=w.getBalance();
		if(currentbal.compareTo(amount)>0){
			BigDecimal newbal= currentbal.subtract(amount);
			w.setBalance(newbal);
			cust.setWallet(w);
			wrepo.save(cust);
		
			Customer cust1=wrepo.findOne(mobileNo);
		
		return cust1;
		}
		else
			throw new InsufficientBalanceException("Current balance is lesser than Withdraw Ammount ");
	}

	@Override
	public boolean ValidateName(String name) throws InvalidInputException {
		if(name==null)
			throw new InvalidInputException("Name field cannot be empty");
		Pattern pat=Pattern.compile("[A-Za-z ]{1,20}");
		Matcher mat=pat.matcher(name);
		return mat.matches();
	}

	@Override
	public boolean ValidateMobNo(String MobNo) throws InvalidInputException {
		if(MobNo==null)
			throw new InvalidInputException("Number connot be zero");
		Pattern pat=Pattern.compile("[6-9]{1}[0-9]{2,9}");
		Matcher mat=pat.matcher(MobNo);
		return mat.matches();
		
	}

	@Override
	public boolean ValidateAmount(BigDecimal amount) throws InvalidInputException {
		
		if(amount==null)
		throw new InvalidInputException("Number connot be zero");
	Pattern pat=Pattern.compile("[1-9]{1}[0-9]{1,5}");
	Matcher mat=pat.matcher(String.valueOf(amount));
	return mat.matches();
	}

	
}
