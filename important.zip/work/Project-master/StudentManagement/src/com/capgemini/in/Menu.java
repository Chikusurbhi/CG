package com.capgemini.in;

import java.util.Scanner;

public class Menu {
	private static Scanner sc=new Scanner(System.in);
	private static Scheduler sch=new Scheduler();

	public static void main(String[] args) {
		    showMenu();
		    
	}
	private static void showMenu() {
		int choice;
		while(true)
		{
			System.out.println("1.Add Student");
			System.out.println("2.Show all students");
			System.out.println("3.exit");
			System.out.println("enter your choice:");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1:addStudentDetails();
			       break;
			case 2:showAllStudents();
			       break;
			case 3:exit();
			       break;
				   
			
			default:System.out.println("you entered wrong choice");
			
			
			
			}
		}
	}
private static void showAllStudents() {
	sch.showAllStudents();
	
}
private static void addStudentDetails() {
	System.out.println("enter roll number");
	int rollnumber=sc.nextInt();
	System.out.println("enter student name");
	String name=sc.next();
	System.out.println(sch.addStudent(rollnumber, name));
}
public static void exit() {
	sch.exit();
}
}
