package com.capgemini.in;

public class Scheduler {

	private Student[] students=new Student[10];
	private int countStud;
	public String addStudent(int rollNumber,String name)
	{
		
		students[countStud++]=new Student(rollNumber,name);
		return "Student added successfully";
		
	}
	
	public void showAllStudents()
	{
		for(int i=0;i<countStud;i++)
		{
			System.out.println(students[i].getRollnumber());
			System.out.println(students[i].getName());
		}
	}
		public void exit(){
			System.exit(0);
		}
			
		}
		

			

	