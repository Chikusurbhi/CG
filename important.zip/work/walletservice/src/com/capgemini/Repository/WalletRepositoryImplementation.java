package com.capgemini.Repository;


import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import com.capgemini.beans.Customer;

public class WalletRepositoryImplementation implements WalletRepository{
	Map<String,Customer>map=new HashMap<>();
	@Override
	public boolean Save(Customer c) {
		
		if(map.containsKey(c.getPhoneNumber()))
			return false;
		map.put(c.getPhoneNumber(),c);
		return true;
		
	}
	@Override
	public Customer FindByPhoneNumber(String phonenumber) 
	{
		for(Entry<String, Customer> entry:map.entrySet())
		if(entry.getKey().equals(phonenumber))
			return entry.getValue();
		return null;
	}
	
}
