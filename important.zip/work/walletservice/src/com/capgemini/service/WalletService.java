package com.capgemini.service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import com.capgemini.exceptions.DuplicatePhoneNumberException;
import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.PhoneNumberDoesNotExistException;

public interface WalletService {
	public Customer createAccount(String name, String phonenumber, BigDecimal amount) throws DuplicatePhoneNumberException, PhoneNumberDoesNotExistException;
	public Customer showBalance(String phonenumber) throws PhoneNumberDoesNotExistException;
   public	Customer fundTransfer(String sourcePhoneNumber,String targetPhoneNumber, BigDecimal amount) throws InsufficientBalanceException,PhoneNumberDoesNotExistException;
    public Customer depositAmount(String phonenumber,BigDecimal amount) throws PhoneNumberDoesNotExistException, InsufficientBalanceException;
	public boolean validate(Customer c) throws PhoneNumberDoesNotExistException;

    public Customer withdrawAmount(String phonenumber,BigDecimal amount) throws InsufficientBalanceException;
}
