package com.capgemini.view;

import java.math.BigDecimal;

import com.capgemini.Repository.WalletRepositoryImplementation;
import com.capgemini.exceptions.DuplicatePhoneNumberException;
import com.capgemini.exceptions.InsufficientBalanceException;
import com.capgemini.exceptions.PhoneNumberDoesNotExistException;
import com.capgemini.service.WalletService;
import com.capgemini.service.WalletServiceImplmentation;

public class PaymentWalletApp
{
	
	public static void main(String[] args) throws DuplicatePhoneNumberException,PhoneNumberDoesNotExistException,InsufficientBalanceException 
	
	{
WalletService walletservice= new WalletServiceImplmentation( new WalletRepositoryImplementation());
// createAccount
System.out.println(walletservice.createAccount("priyam","123", new BigDecimal("4000")));
System.out.println(walletservice.createAccount("shubham","1234",new BigDecimal("5000")));
//showBalance
System.out.println(walletservice.showBalance("123"));
System.out.println(walletservice.showBalance("1234"));
//fundTransfer
System.out.println(walletservice.fundTransfer("123","1234", new BigDecimal("6000")));
//System.out.println(walletservice.fundTransfer("3","4", new BigDecimal("7000")));
//depositAmount
System.out.println(walletservice.depositAmount("123", new BigDecimal("8000")));
System.out.println(walletservice.depositAmount("1234", new BigDecimal("9000")));
//withdrawAmount
System.out.println(walletservice.withdrawAmount("123", new BigDecimal("100")));
//System.out.println(walletservice.withdrawAmount("1234", new BigDecimal("10000")));

}
}
	
	
	
	
	
