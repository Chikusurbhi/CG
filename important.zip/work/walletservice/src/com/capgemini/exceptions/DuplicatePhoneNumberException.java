package com.capgemini.exceptions;

public class DuplicatePhoneNumberException extends Exception {

}
