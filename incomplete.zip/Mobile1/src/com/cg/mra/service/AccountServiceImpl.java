package com.cg.mra.service;

import java.util.List;

import com.cg.mra.beans.Account;
import com.cg.mra.dao.AccountDAO;
import com.cg.mra.dao.AccountDAOImpl;

public class AccountServiceImpl implements AccountService {
	
	private AccountDAO daoref= new AccountDAOImpl();
	
	

	@Override
	public Account getAccountDetails(String mobileNo) {
		Account accounts = daoref.getAccountDetails(mobileNo);
		return  accounts; 
		
	}



	@Override
	public double rechrageAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;
	}
}

	/*@Override
	public double rechrageAccount(String mobileno, double rechargeAmount) {
		// TODO Auto-generated method stub
		return 0;*/
	


