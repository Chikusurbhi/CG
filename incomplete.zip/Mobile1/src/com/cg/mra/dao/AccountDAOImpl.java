package com.cg.mra.dao;

import java.util.HashMap;
import java.util.Map;

import com.cg.mra.beans.Account;

public class AccountDAOImpl implements AccountDAO {
	Map<String,Account> accountEntry;
	
	public AccountDAOImpl()
	{
		accountEntry= new  HashMap<>();
		Account account1 = new Account("prepaid","Vaishali",200);
		
		accountEntry.put("9010210131",account1 );
		
		
Account account2 = new Account("prepaid","Megha",453);
		
		accountEntry.put("9823920123",account2 );
		
Account account3 = new Account("prepaid","vikas",631);
		
		accountEntry.put("9932012345",account3 );	
		
Account account4 = new Account("prepaid","Anju",521);
		
		accountEntry.put("9010210132",account4 );
Account account5 = new Account("prepaid","Tushar",632);
		
		accountEntry.put("9010210133",account5 );
		}
		@Override
	public Account getAccountDetails(String mobileNo) {
			Account a=accountEntry.get(mobileNo);
			if(a==null)
				return null;
			return a;
			}
		@Override
		public double rechargeAccount(String mobileNo, double rechargeAmount) {
			// TODO Auto-generated method stub
			return 0;
		}

	/*@Override
	public double rechargeAccount(String mobileNo, double rechargeAmount) {
		Account accountRef;
		accountRef = accountEntry.(mobileNo, rechargeAmount);
	
		if(accountRef == null)
			return true;
	
			return false;
	
	}*/
	
	
	
	
	
	

}
