package com.cg.mra.beans;

public class Account {
	private String AccounType;
	private String CustomerName;
	private double accountBalance;
	
	public Account(String accounType, String customerName, double accountBalance) 
	{
		this.AccounType = accounType;
		CustomerName = customerName;
		this.accountBalance = accountBalance;
		
	}
	public String getAccounType() {
		return AccounType;
	}
	public void setAccounType(String accounType) {
		AccounType = accounType;
	}
	public String getCustomerName() {
		return CustomerName;
	}
	public void setCustomerName(String customerName) {
		CustomerName = customerName;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
