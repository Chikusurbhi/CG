package com.cg.mra.ui;

import java.util.List;
import java.util.Scanner;

import com.cg.mra.beans.Account;
import com.cg.mra.service.AccountService;
import com.cg.mra.service.AccountServiceImpl;

public class MainUI {
	
	private static  Scanner sc;
	public static void main(String[] args)
	{
		
		sc = new Scanner(System.in);
		
		
			AccountService	service = new AccountServiceImpl();
		
		
		System.out.println("1. Account Balance Enquiry");
		System.out.println("2. Recharge Account");
		System.out.println("3. Exit");
		
		int choice = sc.nextInt();
		switch (choice)
		{
	
		
		System.out.println("Enter Mobile No: ");
		String mobNo = sc.next();
		Account a=service.getAccountDetails(mobNo);
		if(a==null)
		
			System.out.println("no details");
		else 
			System.out.println("Your Current Balance is Rs. \"+acc.getAccountBalance()");
		
		
		   
		}
		
	
		}
	}

	
		

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
	
	
	
	
	
	
	

}
