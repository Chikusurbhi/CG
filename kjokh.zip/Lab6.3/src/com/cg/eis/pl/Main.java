package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.EmployeeException;

public class Main {

	public static void main(String[] args) {
		EmployeeException s= new EmployeeException();
		 Employee e= s.setDetails();
		 Scanner scan= new Scanner(System.in);
		 s.insurancescheme(e.getSalary(),e.getDesignation(), e);
		 s.getDetails();
		 scan.close();
		 try
		 {
			 s.validate();
		 }
		 catch(Exception n)
		 {
			 System.out.println("Exception");
		 }
	

}
}
