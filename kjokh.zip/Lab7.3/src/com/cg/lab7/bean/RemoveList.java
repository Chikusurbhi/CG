package com.cg.lab7.bean;
import java.util.*;
public class RemoveList {

	public static void main(String[] args) {
		ArrayList<String> list1= new ArrayList<String>();
		list1.add("Ana");
		list1.add("Nick");
		list1.add("Kathy");
		list1.add("John");
		
		ArrayList<String> list2= new ArrayList<String>();
		list2.add("Ana");
		list2.add("John");
		RemoveList rl=new RemoveList();
		rl.removeList(list1,list2);
		
		
		}

	private void removeList(List list1,List list2) {
		ArrayList<String> a1= new ArrayList<String>();
		ArrayList<String> a2= new ArrayList<String>();
		a1.addAll(list1);
		a2.addAll(list2);
		a1.removeAll(a2);
		Iterator i=a1.iterator();
		System.out.println("Elements after removing from second list:");
		while(i.hasNext())
			System.out.println(i.next());
	}

	
		
	}


