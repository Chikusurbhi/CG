package com.cg.eis.pl;

import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Services;

public class Main {

	public static void main(String[] args)
	{
		 Services s= new Services();
		 Employee e= s.setDetails();
		 Scanner scan= new Scanner(System.in);
		 s.insurancescheme(e.getSalary(),e.getDesignation(), e);
		 
			s.getDetails();
		 
		 

	}

}
