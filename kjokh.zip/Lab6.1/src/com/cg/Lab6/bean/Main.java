package com.cg.Lab6.bean;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner sc= new Scanner(System.in);
		System.out.println("Enter your first name:");
		String firstName= sc.nextLine();
		System.out.println("Enter your last name:");
		String lastName= sc.nextLine();
		sc.close();
		NameExceptionValidation m= new NameExceptionValidation(firstName, lastName);
		 
	    try
	    {
	    	m.validate();
	    }
	    catch(Exception e)
	    {
       System.out.println("Exception");
	    }
		

	}

}
