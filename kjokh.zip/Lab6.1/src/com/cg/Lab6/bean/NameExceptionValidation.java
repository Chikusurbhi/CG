package com.cg.Lab6.bean;
 class NameException extends Exception 
{
	NameException(String s)
	{
		super(s);
	}
}
public class NameExceptionValidation {

		private String firstName;
		private String lastName;
		
	
		public NameExceptionValidation (String firstName, String lastName) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		
		
		public void validate() throws NameException
		{
			if(firstName.equals("") && lastName.equals(""))
			{
				throw new NameException("Name is blank");
			}
			else
				System.out.println("Name is "+ firstName +lastName);
		}
	
	}
