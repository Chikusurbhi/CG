package com.cg.Lab6.bean;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner scan= new Scanner(System.in);
		System.out.println("Enter your age");
		int age= scan.nextInt();
		scan.close();
		Age a=new Age(age);
		try
		{
			a.validate();
		}
		catch(Exception e)
		{
			System.out.println("Exception");
		}

	}

}
