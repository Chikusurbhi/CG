package com.capgemini.main;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.service.WalletService;
import com.capgemini.service.WalletServiceImpl;

public class UIMain {
	
	public static void main(String[] args)
	{
		WalletService walletref = new WalletServiceImpl();
		//Customer ref= new Customer("Priya","9849377",new Wallet(9,new BigDecimal("78898.485845983")));
		
		Customer c1=walletref.createAccount("priya", "8745321659", new BigDecimal("678900.9766"));
	
		Customer c2=walletref.showBalance("9834598234");
		System.out.println(c2.getWallet().getBalance());
		
		Customer c3=walletref.fundTransfer("9834598264", "9834598234", new BigDecimal("678900.9766"));
		System.out.println(c3);
		
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
	

}
