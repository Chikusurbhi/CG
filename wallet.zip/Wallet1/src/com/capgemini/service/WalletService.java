package com.capgemini.service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;

public interface WalletService {
	Customer createAccount(String Name,String PhoneNumber,BigDecimal Amount);
	public Customer showBalance(String mobileNumber) ;
	public Customer fundTransfer(String sourceMobileNumber,String targetMobileNumber,BigDecimal amount);
	public Customer depositAmount(String mobileNumber,BigDecimal amount) ;
	public Customer withdrawAmount(String mobileNumber,BigDecimal amount) ;

	
}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


