package com.capgemini.service;

import java.math.BigDecimal;

import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;
import com.capgemini.dao.WalletDAO;
import com.capgemini.dao.WalletDAOImpl;

public class WalletServiceImpl  implements WalletService{
	static int c=5;
	WalletDAO DAOref;
	
	
	
	public WalletServiceImpl() {
		
		DAOref = new WalletDAOImpl();
	}

	@Override
	public Customer createAccount(String Name, String PhoneNumber, BigDecimal Amount) {
		Wallet a = new Wallet(c++,Amount);
		Customer m= new Customer("sakshi","8743521986",a);
		DAOref.save(m);
		return m;
	}

	@Override
	public Customer showBalance(String mobileNumber) {
		Customer a= DAOref.FindByNumber(mobileNumber);
		
		return a;
		
	}

	@Override
	public Customer fundTransfer(String sourceMobileNumber, String targetMobileNumber, BigDecimal amount) {
		Customer sr= DAOref.FindByNumber(sourceMobileNumber);
		Customer tg= DAOref.FindByNumber(targetMobileNumber);
		tg.getWallet().setBalance(tg.getWallet().getBalance().add(amount));
		sr.getWallet().setBalance(sr.getWallet().getBalance().subtract(amount));
		
		
		return tg;
	}

	@Override
	public Customer depositAmount(String mobileNumber, BigDecimal amount) {
		
		Customer a= DAOref.FindByNumber(mobileNumber);
		a.getWallet().setBalance(a.getWallet().getBalance().add(amount));
		
		
	
		return a;
	}

	@Override
	public Customer withdrawAmount(String mobileNumber, BigDecimal amount) {
		Customer b= DAOref.FindByNumber(mobileNumber);
		b.getWallet().setBalance(b.getWallet().getBalance().subtract(amount));
		return b;
	}

}
