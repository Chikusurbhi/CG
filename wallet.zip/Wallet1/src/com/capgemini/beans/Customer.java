package com.capgemini.beans;

public class Customer {
	
	private String Name;
	private String PhoneNumber;
	 private Wallet wallet;
	public Customer(String name, String phoneNumber, Wallet wallet) {
		
		this.Name = name;
		this.PhoneNumber = phoneNumber;
		this.wallet = wallet;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public String getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public Wallet getWallet() {
		return wallet;
	}
	public void setWallet(Wallet wallet) {
		this.wallet = wallet;
	}
	@Override
	public String toString() {
		return "Customer [Name=" + Name + ", PhoneNumber=" + PhoneNumber + ", wallet=" + wallet + "]";
	}
	
	
		
	
	
	

}
