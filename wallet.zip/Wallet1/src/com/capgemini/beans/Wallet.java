package com.capgemini.beans;

import java.math.BigDecimal;

public class Wallet {
	int ID;
	BigDecimal balance;
	public Wallet(int iD, BigDecimal balance) {
	
		this.ID = iD;
		this.balance = balance;
	
	}
	


	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public BigDecimal getBalance() {
		return balance;
	}
	public void setBalance(BigDecimal balance) {
		this.balance = balance;
	}



	@Override
	public String toString() {
		return "Wallet [ID=" + ID + ", balance=" + balance + "]";
	}
	
	}
	
