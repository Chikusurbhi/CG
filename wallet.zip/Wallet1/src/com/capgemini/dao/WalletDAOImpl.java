package com.capgemini.dao;

import java.math.BigDecimal;
import java.util.Map;
import java.util.TreeMap;


import com.capgemini.beans.Customer;
import com.capgemini.beans.Wallet;

public class WalletDAOImpl  implements WalletDAO
{
	private Map<String,Customer> CustomerDetails;
	public WalletDAOImpl()
	{
		CustomerDetails= new TreeMap<>();
		Wallet w=new Wallet(1,new BigDecimal(100000));
		Customer cus= new Customer("priya", "9834598234", w);
		CustomerDetails.put(cus.getPhoneNumber(),cus);
		Wallet w1=new Wallet(2,new BigDecimal(300000));
		Customer cus1= new Customer("priyam", "9834598264", w1);
		CustomerDetails.put(cus1.getPhoneNumber(),cus1);	
		
		
		Wallet w2=new Wallet(3,new BigDecimal(700000));
		Customer cus2= new Customer("priyas", "9834598274", w2);
		CustomerDetails.put(cus2.getPhoneNumber(),cus2);
		Wallet w3=new Wallet(4,new BigDecimal(800000));
		Customer cus3= new Customer("priyanka", "9834596234", w3);
		CustomerDetails.put(cus3.getPhoneNumber(),cus3);
		
		
	}
	
	
	
	
	
	@Override

	public boolean save(Customer customer) {
		
		Customer b= CustomerDetails.put(customer.getPhoneNumber(),customer );
		
		if(b==null)
			return true;
		
		return false ;
	}

	@Override
	public Customer FindByNumber(String PhoneNumber) {
		Customer c= CustomerDetails.get(PhoneNumber);
		//System.out.println(c);
		return c;
	}

}
