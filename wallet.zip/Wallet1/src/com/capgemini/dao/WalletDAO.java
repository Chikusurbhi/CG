package com.capgemini.dao;

import com.capgemini.beans.Customer;

public interface WalletDAO {
	boolean save(Customer customer);
	Customer FindByNumber(String PhoneNumber);
	
	
	
	
	}
