package capgemini.com.beans;

public class Teller {
	public void PerformTransfer()
	{
		Bank b= new Bank();
		b.transferAmount(5, 3,10000);
	
		
				
	}
	
	{
		
	}

	public void showTotalBalance() {
		Bank b= new Bank();
		b.showTotalBalance();
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

}
