package capgemini.com.beans;

public class Bank {
	Accounts[] acc = new Accounts[5];
	public Bank()
	{
		
		acc[0]=new Accounts(1,45000);
		
		acc[1]=new Accounts(2,75000);
		
		acc[2]=new Accounts(5,25000);
		acc[3]=new Accounts(3,45000);
		acc[4]=new Accounts(4,75000);
	}
	
	void transferAmount(int toAccounts,int fromAccounts,double Amount)
	{

	for(int i=0;i<=4;i++)
	{
		if(acc[i].getId()==fromAccounts)
			acc[i].withdraw(Amount);
			if(acc[i].getId()==toAccounts)
				acc[i].deposit(Amount);
	}
	
	System.out.println(acc[2].getBalance());
	System.out.println(acc[3].getBalance());
			
		}
	
	
	
	
	
	
	
	
	void showTotalBalance()
	{
		
		
		double sum=0;
		for(int i=0;i<=4;i++)
			
			
			
			
			
			
			
			sum=sum+acc[i].getBalance();
		System.out.println(sum);
		{
			
			
			
			
			
			
			
			
			
		}
	}
	}

		
		
		
		
		
		
		
		
		


	


	
