package capgemini.com.beans;

public class Accounts {
	int Id;
	double Balance;	
	public Accounts(int id, double balance) {
	
		Id = id;
		Balance = balance;
	}



	
	public int getId() {
		return Id;
	}
	public void setId(int id) {
		Id = id;
	}
	public double getBalance() {
		return Balance;
	}
	public void setBalance(double balance) {
		Balance = balance;
	}
	public boolean deposit (double amount)
	{
		this.Balance += amount;
		return true;
	
	}
	
	
	
public boolean withdraw(double amount) {
		if(this.Balance >= amount) {
			this.Balance -= amount;
			return true;
		}
		return false;
	}
}
	
	
	
	
	
	
	


