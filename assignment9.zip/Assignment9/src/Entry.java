import capgemini.com.beans.Teller;

public class Entry {
	public static void main(String[] args)
	{
		
		Teller c=new Teller();
				
			c.PerformTransfer();
			c.showTotalBalance();
			
			
				
				
				
				
				}
		
	}

